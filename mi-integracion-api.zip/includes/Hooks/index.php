<?php
// Silencio es dorado
// Este archivo existe para evitar listados de directorio
