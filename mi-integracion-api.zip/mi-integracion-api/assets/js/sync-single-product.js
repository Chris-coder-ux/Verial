/**
 * JavaScript para la página de sincronización individual de productos
 *
 * Este script maneja:
 * - Validación del formulario
 * - Autocompletado de productos
 * - Carga de categorías y fabricantes
 * - Envío del formulario de sincronización
 */
jQuery(document).ready(function($) {
    console.log('Script de sincronización individual cargado');
    
    /**
     * Función para obtener el nonce de seguridad de múltiples fuentes posibles
     * Garantiza compatibilidad entre páginas y contextos diferentes
     */
    function getNonceValue() {
        // 1. Buscar en elementos con name="_ajax_nonce" (fuente principal)
        let ajaxNonce = $('input[name="_ajax_nonce"]').val();
        if (ajaxNonce) {
            console.log('Usando nonce de input[name="_ajax_nonce"]');
            return ajaxNonce;
        }
        
        // 2. Intentar obtener del objeto global miIntegracionApiDashboard
        if (typeof miIntegracionApiDashboard !== 'undefined' && miIntegracionApiDashboard.nonce) {
            console.log('Usando nonce de miIntegracionApiDashboard');
            return miIntegracionApiDashboard.nonce;
        }
        
        // 3. Buscar en otros campos de nonce comunes de WordPress
        const possibleNonceFields = ['_wpnonce', 'security', 'nonce'];
        for (let fieldName of possibleNonceFields) {
            let nonceValue = $(`input[name="${fieldName}"]`).val();
            if (nonceValue) {
                console.log(`Usando nonce de input[name="${fieldName}"]`);
                return nonceValue;
            }
        }
        
        // 4. Buscar en datos de elementos con atributo data-nonce 
        let dataNonce = $('[data-nonce]').first().data('nonce');
        if (dataNonce) {
            console.log('Usando nonce de elemento con data-nonce');
            return dataNonce;
        }
        
        console.error('No se pudo encontrar un nonce válido en ninguna fuente');
        return null;
    }
    
    // Referencias a los elementos del formulario
    const $form = $('#mi-sync-single-product-form');
    const $skuInput = $('#sku');
    const $nombreInput = $('#nombre');
    const $categoriaSelect = $('#categoria');
    const $fabricanteSelect = $('#fabricante');
    const $syncButton = $('#sync-button');
    const $spinner = $('.spinner');
    const $resultContainer = $('#sync-result');
    
    // Cargar categorías y fabricantes al cargar la página
    initSelects();
    
    // Configurar autocompletado para SKU y nombre
    setupAutocomplete();
    
    // Manejar envío del formulario
    $form.on('submit', function(e) {
        e.preventDefault();
        syncProduct();
    });
    
    /**
     * Inicializa los selects de categoría y fabricante
     */
    function initSelects() {
        console.log('Inicializando selectores...');
        console.log('Nonce disponible:', $('input[name="_ajax_nonce"]').length > 0);
        console.log('Valor del nonce:', getNonceValue());
        
        // Obtener categorías
        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'mi_sync_get_categorias',
                _ajax_nonce: getNonceValue()
            },
            success: function(response) {
                console.log('Respuesta categorías:', response);
                if (response.success && response.data && response.data.categories) {
                    console.log('Categorías recibidas:', response.data.categories);
                    populateSelect($categoriaSelect, response.data.categories);
                } else {
                    console.error('Error al cargar categorías:', response);
                    alert('Error al cargar categorías. Revisa la consola para más detalles.');
                }
            },
            error: function(xhr, status, error) {
                console.error('Error AJAX al cargar categorías:', status, error);
                console.log('Respuesta error:', xhr.responseText);
                alert('Error de comunicación al cargar categorías: ' + status);
            }
        });
        
        // Obtener fabricantes
        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'mi_sync_get_fabricantes',
                _ajax_nonce: getNonceValue()
            },
            success: function(response) {
                if (response.success && (response.data.manufacturers || response.data.fabricantes)) {
                    populateSelect($fabricanteSelect, response.data.manufacturers || response.data.fabricantes);
                } else {
                    console.error('Error al cargar fabricantes:', response);
                }
            },
            error: function(xhr, status, error) {
                console.error('Error AJAX al cargar fabricantes:', status, error);
            }
        });
    }
    
    /**
     * Rellena un select con opciones
     */
    function populateSelect($select, items) {
        // Mantener la opción por defecto
        const defaultOption = $select.find('option').first().clone();
        $select.empty().append(defaultOption);
        
        // Añadir nuevas opciones
        $.each(items, function(id, name) {
            $select.append($('<option>', {
                value: id,
                text: name
            }));
        });
    }
    
    /**
     * Configura el autocompletado para SKU y nombre
     */
    function setupAutocomplete() {
        // Autocompletado para ID/Código de barras
        $skuInput.autocomplete({
            minLength: 2,
            source: function(request, response) {
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'mi_search_product',
                        _ajax_nonce: getNonceValue(),
                        search: request.term,
                        field: 'id' // Buscar por ID o código de barras
                    },
                    success: function(data) {
                        if (data.success && data.data.products) {
                            response(data.data.products);
                        } else {
                            response([]);
                        }
                    },
                    error: function() {
                        response([]);
                    }
                });
            },
            select: function(event, ui) {
                $skuInput.val(ui.item.value);
                // Si es seleccionado por ID o código, limpiar nombre
                $nombreInput.val('');
                return false;
            }
        }).autocomplete("instance")._renderItem = function(ul, item) {
            return $("<li>")
                .append("<div><strong>" + item.value + "</strong> - " + item.label + "</div>")
                .appendTo(ul);
        };
        
        // Autocompletado para nombre
        $nombreInput.autocomplete({
            minLength: 3,
            source: function(request, response) {
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'mi_search_product',
                        _ajax_nonce: getNonceValue(),
                        search: request.term,
                        field: 'name'
                    },
                    success: function(data) {
                        if (data.success && data.data.products) {
                            response(data.data.products);
                        } else {
                            response([]);
                        }
                    },
                    error: function() {
                        response([]);
                    }
                });
            },
            select: function(event, ui) {
                $nombreInput.val(ui.item.label);
                // Si se selecciona por nombre, poner el ID/código en el otro campo
                if (ui.item.id) {
                    $skuInput.val(ui.item.id);
                }
                return false;
            }
        });
    }
    
    /**
     * Sincroniza el producto con la información del formulario
     */
    function syncProduct() {
        // Validación básica
        if ($skuInput.val() === '' && $nombreInput.val() === '' && 
            $categoriaSelect.val() === '' && $fabricanteSelect.val() === '') {
            showResult('error', 'Debes especificar al menos un campo de búsqueda');
            return;
        }
        
        // Mostrar indicador de carga
        $syncButton.prop('disabled', true);
        $spinner.css('visibility', 'visible');
        
        // Enviar solicitud
        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'mi_sync_single_product',
                _ajax_nonce: getNonceValue(),
                sku: $skuInput.val(),
                nombre: $nombreInput.val(),
                categoria: $categoriaSelect.val(),
                fabricante: $fabricanteSelect.val()
            },
            success: function(response) {
                console.log('Respuesta de sincronización:', response);
                if (response.success) {
                    showResult('success', response.data.message);
                } else {
                    showResult('error', response.data.message || 'Error al sincronizar el producto');
                }
            },
            error: function(xhr, status, error) {
                console.error('Error AJAX al sincronizar:', status, error);
                showResult('error', 'Error de comunicación: ' + status);
            },
            complete: function() {
                $syncButton.prop('disabled', false);
                $spinner.css('visibility', 'hidden');
            }
        });
    }
    
    /**
     * Muestra el resultado de la operación
     */
    function showResult(type, message) {
        if (!$resultContainer.length) {
            $resultContainer = $('<div id="sync-result"></div>');
            $form.after($resultContainer);
        }
        
        const className = type === 'success' ? 'notice-success' : 'notice-error';
        $resultContainer.html(
            `<div class="notice ${className} is-dismissible"><p>${message}</p></div>`
        );
        
        // Scroll al resultado
        $('html, body').animate({
            scrollTop: $resultContainer.offset().top - 50
        }, 500);
        
        // Hacer que los notices sean descartables como en WP admin
        if (window.jQuery && window.jQuery.fn.on) {
            setTimeout(function() {
                window.wp?.notices?.init();
            }, 100);
        }
    }
});
